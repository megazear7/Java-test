import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;

public class GlossaryTest {

    @Test
    public void generateElementsTest_a() {
        Set<Character> test = new Set1L<Character>();
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('a');
        String s = "a";
        Glossary.generateElements(s, test);
        assertTrue(test.equals(noChange));
    }

    @Test
    public void generateElementsTest_abc() {
        Set<Character> test = new Set1L<Character>();
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('a');
        noChange.add('b');
        noChange.add('c');
        String s = "abc";
        Glossary.generateElements(s, test);
        assertTrue(test.equals(noChange));
    }

    @Test
    public void generateElementsTest_abcA() {
        Set<Character> test = new Set1L<Character>();
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('a');
        noChange.add('b');
        noChange.add('c');
        noChange.add('A');
        String s = "abcA";
        Glossary.generateElements(s, test);
        assertTrue(test.equals(noChange));
    }

    @Test
    public void nextWordOrSeparatorTest_1() {
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('-');
        noChange.add('/');
        noChange.add('*');
        noChange.add('!');
        String s = "abc-def-ghi";
        String a = Glossary.nextWordOrSeparator(s, 4, noChange);
        assertEquals(a, "def");
    }

    @Test
    public void nextWordOrSeparatorTest_2() {
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('-');
        noChange.add('/');
        noChange.add('*');
        noChange.add('!');
        String s = "abc-/*-def-ghi";
        String a = Glossary.nextWordOrSeparator(s, 3, noChange);
        assertEquals(a, "-/*-");
    }

    @Test
    public void nextWordOrSeparatorTest_3() {
        Set<Character> noChange = new Set1L<Character>();
        noChange.add('-');
        noChange.add('/');
        noChange.add('*');
        noChange.add('!');
        String s = "abc-def-ghi";
        String a = Glossary.nextWordOrSeparator(s, 8, noChange);
        assertEquals("ghi", a);
    }

    @Test
    public void generateTermsTest() {
        SimpleReader input = new SimpleReader1L("data/terms.txt");
        Set<String> terms = Glossary.generateTerms(input);
        Set<String> noChange = new Set1L<String>();
        assertTrue(terms.contains("meaning"));
        assertTrue(terms.contains("term"));
        assertTrue(terms.contains("word"));
        assertTrue(terms.contains("definition"));
        assertTrue(terms.contains("glossary"));
        assertTrue(terms.contains("language"));
        assertTrue(terms.contains("book"));

    }

    @Test
    public void generateTermsTest_2() {
        SimpleReader input = new SimpleReader1L("data/terms.txt");
        Set<String> terms = Glossary.generateTerms(input);
        Set<String> noChange = new Set1L<String>();
        noChange.add("meaning");
        noChange.add("term");
        noChange.add("word");
        noChange.add("definition");
        noChange.add("glossary");
        noChange.add("language");
        noChange.add("book");
        assertTrue(noChange.equals(terms));

    }

    @Test
    public void setOrderTest() {
        Set<String> set = new Set1L<String>();
        set.add("alex");
        set.add("mikayla");
        set.add("zoro");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "alex");
        noChange.add(1, "mikayla");
        noChange.add(2, "zoro");

        Sequence<String> test = Glossary.setOrder(set);
        assertEquals(noChange, test);
    }

    @Test
    public void findPosTest() {
        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "alex");
        noChange.add(1, "mikayla");
        noChange.add(2, "zoro");

        String s = "bottom";
        int i = Glossary.findPos(s, noChange);
        assertEquals(1, i);
    }

    @Test
    public void findPosTest_2() {
        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "alex");
        noChange.add(1, "mikayla");
        noChange.add(2, "thor");

        String s = "otter";
        int i = Glossary.findPos(s, noChange);
        assertEquals(2, i);
    }

    @Test
    public void findPosTest_3() {
        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "alex");
        noChange.add(1, "mikayla");
        noChange.add(2, "thor");

        Sequence<String> test = new Sequence1L<String>();
        test.add(0, "alex");
        test.add(1, "mikayla");
        test.add(2, "thor");

        String s = "zoro";
        int i = Glossary.findPos(s, test);
        assertEquals(3, i);
        assertEquals(noChange, test);
    }

    @Test
    public void findPosTest_4() {
        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bam");

        String s = "clex";
        int i = Glossary.findPos(s, noChange);
        assertEquals(1, i);
        String t = noChange.remove(0);
        assertEquals("bam", t);
    }

    @Test
    public void findPosTest_5() {
        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bam");
        String s = "alex";
        int i = Glossary.findPos(s, noChange);
        assertEquals(0, i);
    }

    @Test
    public void findPosTest_6() {
        Sequence<String> noChange = new Sequence1L<String>();
        String s = "alex";
        int i = Glossary.findPos(s, noChange);
        assertEquals(0, i);
    }

    @Test
    public void setOrderTest_stage1_1() {
        Set<String> original = new Set1L<String>();
        Sequence<String> noChange = new Sequence1L<String>();
        String s = "alex";
        int i = Glossary.findPos(s, noChange);
        Sequence<String> test = Glossary.setOrder(original);
        assertEquals(0, i);
        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_2() {
        Set<String> original = new Set1L<String>();
        original.add("bottom");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bottom");

        Sequence<String> test = new Sequence1L<String>();

        test = Glossary.setOrder(original);

        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_3() {
        Set<String> original = new Set1L<String>();
        original.add("otten");
        original.add("bottom");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bottom");
        noChange.add(1, "otten");

        Sequence<String> test = new Sequence1L<String>();

        test = Glossary.setOrder(original);

        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_4() {
        Set<String> original = new Set1L<String>();
        original.add("bottom");
        original.add("otten");
        original.add("eve");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bottom");
        noChange.add(1, "eve");
        noChange.add(2, "otten");

        Sequence<String> test = new Sequence1L<String>();

        test = Glossary.setOrder(original);

        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_5() {
        Set<String> original = new Set1L<String>();
        original.add("otten");
        original.add("bottom");
        original.add("eve");
        original.add("zoro");

        Set<String> originalNoChange = new Set1L<String>();
        originalNoChange.add("otten");
        originalNoChange.add("bottom");
        originalNoChange.add("eve");
        originalNoChange.add("zoro");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "bottom");
        noChange.add(1, "eve");
        noChange.add(2, "otten");
        noChange.add(3, "zoro");

        Sequence<String> test = new Sequence1L<String>();

        test = Glossary.setOrder(original);

        assertEquals(originalNoChange, original);
        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_6() {
        Set<String> original = new Set1L<String>();
        original.add("dennis");
        original.add("dwarves");
        original.add("elves");
        original.add("hobbits");
        original.add("human");
        original.add("sauron");
        original.add("lord");
        original.add("person");

        Set<String> originalNoChange = new Set1L<String>();
        originalNoChange.add("dennis");
        originalNoChange.add("dwarves");
        originalNoChange.add("elves");
        originalNoChange.add("hobbits");
        originalNoChange.add("human");
        originalNoChange.add("sauron");
        originalNoChange.add("lord");
        originalNoChange.add("person");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "dennis");
        noChange.add(1, "dwarves");
        noChange.add(2, "elves");
        noChange.add(3, "hobbits");
        noChange.add(4, "human");
        noChange.add(5, "lord");
        noChange.add(6, "person");
        noChange.add(7, "sauron");

        Sequence<String> test = new Sequence1L<String>();

        test = Glossary.setOrder(original);

        assertEquals(originalNoChange, original);
        assertEquals(noChange, test);
    }

    @Test
    public void setOrderTest_stage1_7() {
        Set<String> original = new Set1L<String>();
        original.add("dennis");
        original.add("dwarves");
        original.add("elves");
        original.add("hobbits");
        original.add("human");
        original.add("sauron");

        Set<String> originalNoChange = new Set1L<String>();
        originalNoChange.add("dennis");
        originalNoChange.add("dwarves");
        originalNoChange.add("elves");
        originalNoChange.add("hobbits");
        originalNoChange.add("human");
        originalNoChange.add("sauron");

        Sequence<String> noChange = new Sequence1L<String>();
        noChange.add(0, "dennis");
        noChange.add(1, "dwarves");
        noChange.add(2, "elves");
        noChange.add(3, "hobbits");
        noChange.add(4, "human");
        noChange.add(5, "lord");
        noChange.add(6, "sauron");

        Sequence<String> test = new Sequence1L<String>();

        int testInt = Glossary.findPos("person", noChange);

        assertEquals(originalNoChange, original);
        assertEquals(6, testInt);
    }
}
