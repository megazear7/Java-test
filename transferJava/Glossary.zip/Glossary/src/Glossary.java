import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * This program asks the user for a file location and a folder location. If the
 * folder exists and the file is correctly formatted then the program will
 * generate a 'gossary' which consists of a grouping of html files. One file is
 * a index with links to the other files in alphebetical order. The other files
 * are terms and descriptions based off of the input file
 * 
 * @author Alex Lockhart
 * @LastUpdate: 4/10/2013
 */
public final class Glossary {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private Glossary() {
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     * 
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces {@code strSet}
     * @ensures <pre>
     * {@code strSet = entries(str)}
     * </pre>
     */
    static void generateElements(String str, Set<Character> strSet) {
        while (str.length() > 0) {
            char a = str.charAt(0);
            str = str.substring(1);
            if (!strSet.contains(a)) {
                strSet.add(a);
            }
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     * 
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires <pre>
     * {@code 0 <= position < |text|}
     * </pre>
     * @ensures <pre>
     * {@code nextWordOrSeparator =
     *   text[position, position + |nextWordOrSeparator|)  and
     * if entries(text[position, position + 1)) intersection separators = {}
     * then
     *   entries(nextWordOrSeparator) intersection separators = {}  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      intersection separators /= {})
     * else
     *   entries(nextWordOrSeparator) is subset of separators  and
     *   (position + |nextWordOrSeparator| = |text|  or
     *    entries(text[position, position + |nextWordOrSeparator| + 1))
     *      is not subset of separators)}
     * </pre>
     */
    static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        String ret = "";
        int length = text.length();

        if (separators.contains(text.charAt(position))) {
            int i = position;
            while ((i < length) && (separators.contains(text.charAt(i)))) {
                ret = ret + text.charAt(i);
                i++;
            }
        } else {
            int i = position;
            while ((i < length) && (!separators.contains(text.charAt(i)))) {
                ret = ret + text.charAt(i);
                i++;
            }
        }

        return ret;
    }

    /**
     * Outputs a standard html header to a file, defining the pages title to be
     * equal to {@code title}
     * 
     * @param out
     *            The output stream to output to
     * @param title
     *            The title of the html page you wish to create
     * @requires the output stream {@code: out} is open
     * @ensures a correct html header is written to {@code: out}
     */
    private static void outputHtmlHeader(SimpleWriter out, String title) {
        out.println("<html><head><title>" + title + "</title></head><body>");
    }

    /**
     * Outputs a standard html footer to the output stream
     * 
     * @param out
     *            The output stream you wish to output to
     * @requires the output stream {@code: out} is open
     * @ensures a correct html footer is wriiten to {@code: out}
     */
    private static void outputHtmlFooter(SimpleWriter out) {
        out.println("</body></html>");
    }

    /**
     * outputs to the output stream {@code: out} the string description as html.
     * Where each word that is in {@code: terms} is a link to that term page
     * 
     * @param out
     *            the output stream
     * @param description
     *            the desccription to be written
     * @param terms
     *            the list of terms that if appear in {@code: description}
     *            should be written as an html link
     * @requires the output stream {@code: out} is open
     */
    private static void outputDescription(SimpleWriter out, String description,
            Set<String> terms) {
        Set<Character> separators = new Set1L<Character>();
        separators.add(' ');
        separators.add(')');
        separators.add('-');

        int pos = 0;
        int desLength = description.length();

        while (pos < desLength) {
            String word = nextWordOrSeparator(description, pos, separators);
            if (terms.contains(word)) {
                out.print(" <a href = '" + word + ".html'>" + word + "</a> ");
            } else {
                out.print(" " + word + " ");
            }
            int length = word.length();
            pos = pos + length;
        }
    }

    /**
     * Creates a html page called "{@code term}.txt" with a term and a
     * description. With all the requirements for term pages.
     * 
     * @updates terms
     * @param term
     *            The term you wish to create a page for
     * @param description
     *            The description of that term
     * 
     * @ensures terms now includes term if it previously didn't.
     */
    static void printTermToFile(String term, String description,
            Set<String> terms, String folder) {

        if (folder.equals("")) {
            folder = "glossary";
        }

        SimpleWriter out = new SimpleWriter1L(folder + "/" + term + ".html");
        outputHtmlHeader(out, term);
        out.println("<h2><b><i><font color='red'>" + term
                + "</font></i></b></h2>");
        out.println("<blockquote>");
        outputDescription(out, description, terms);
        out.println("</blockquote><hr/>");
        out.println("<p>Return to <a href='index.html'>index</a>.</p>");
        outputHtmlFooter(out);
    }

    /**
     * Creates one file for each term in input, which is an html page that has
     * the term as a header and the corrosponding discription as a description.
     * And any word that appears in the description that is in terms is a link
     * to that term page
     * 
     * @param input
     *            input stream to get terms and descriptions from
     * @param terms
     *            the set of terms from that input stream
     * @param folder
     *            represents the folder that the files will be created in
     * @requires the set of terms in {@code: input} and {@code: terms} is
     *           identical
     * @ensures there is a file created for each term, with the correct
     *          discription and links to other term pages.
     */
    static void printTermFiles(SimpleReader input, Set<String> terms,
            String folder) {

        while (!input.atEOS()) {
            String term = input.nextLine();

            String theNextLine = input.nextLine();
            String description = theNextLine;
            if (!input.atEOS()) {
                theNextLine = input.nextLine();
                while (theNextLine.length() > 0) {
                    description = description + " " + theNextLine;
                    theNextLine = input.nextLine();
                }
            }

            printTermToFile(term, description, terms, folder);

            String line = "";
            while (!line.equals("")) {
                if (!input.atEOS()) {
                    line = input.nextLine();
                } else {
                    break;
                }
            }
        }
    }

    /**
     * 
     * @param input
     *            creates a Set of terms from {@code: input}
     * @requires {@code: input} is correctly formatted
     * @ensures generateTerms is a set of terms from {@code: input}
     * @return A set of terms based on {@code: input}
     */
    static Set<String> generateTerms(SimpleReader input) {
        Set<String> terms = new Set1L<String>();
        String term;
        while (!input.atEOS()) {
            term = input.nextLine();

            if ((!terms.contains(term))) {
                terms.add(term);
            }

            String line = "";
            if (!input.atEOS()) {
                line = input.nextLine();
            }
            while (!line.equals("")) {
                if (!input.atEOS()) {
                    line = input.nextLine();
                } else {
                    break;
                }
            }
        }

        return terms;
    }

    /**
     * Makes a html page which is an index of terms. Where each term is a link
     * to its term page. The terms are in lexicographical order
     * 
     * @param terms
     *            terms to make an index of, in the desired order
     * @param folder
     *            location of the file to be written to
     * @requires the directory indicated by {@code: folder} exists
     * @ensures a correct index html file is written, where the terms are in
     *          lexicographical order
     */
    private static void generateIndex(Set<String> termsSet, String folder) {
        SimpleWriter out = new SimpleWriter1L(folder + "/index.html");
        outputHtmlHeader(out, "Glossary");
        out.print("<h2>Glossary</h2><hr /><h3>Index</h3>");

        Sequence<String> terms = setOrder(termsSet);

        int size = terms.length();
        out.println("<ul>");
        for (int i = 0; i < size; i++) {
            String term = terms.remove(0);

            out.println("<li><a href = '" + term + ".html'>" + term
                    + "</a></li>");

        }
        out.print("</ul>");

        outputHtmlFooter(out);
        // TODO: Make this darn thing work
    }

    /**
     * 
     * @param term
     *            The term to check against the sequence
     * @param seq
     *            The sequence to check
     * @Requires seq is in lexicographical order
     * @ensures findPos will equal the correct position to keep {@code: seq} in
     *          lexicographical order
     * @return A position that will make {@code: seq} stay in lexicographical
     *         order
     */
    static int findPos(String term, Sequence<String> seq) {

        Sequence<String> temp = seq.newInstance();
        temp.transferFrom(seq);
        int length = temp.length();
        int ret = length;
        boolean check = true;
        for (int i = 0; i < length; i++) {
            String compare = temp.remove(0);
            // seq.add(pos, compare);
            int seqPos = seq.length();

            seq.add(seqPos, compare);
            if ((term.compareToIgnoreCase(compare) < 0) && (check)) {
                ret = i;
                check = false;
            }
        }

        return ret;
        // TODO: Make this function work!!!
    }

    /**
     * 
     * @param terms
     *            the set to order
     * @requires
     * @ensures setOrder is a sequence in lexicographical order and the set of
     *          items in {@code: terms} and in setOrder are the same
     * @return A sequence where the items are the same as {@code: terms} and are
     *         ordered lexicographically
     */
    static Sequence<String> setOrder(Set<String> terms) {
        Sequence<String> ret = new Sequence1L<String>();

        if (terms.size() == 0) {
            return ret;
        }

        Set<String> temp = terms.newInstance();

        int size = terms.size();

        for (int i = 0; i < size; i++) {
            String term = terms.removeAny();
            temp.add(term);

            int pos = findPos(term, ret);
            ret.add(pos, term);
            // ret.add(pos + 1, Integer.toString(i));
        }

        terms.transferFrom(temp);

        return ret;
        // TODO: and make this one work....
    }

    /**
     * Creates html files, which together make a glossary
     * 
     * @param input
     *            The input stream
     * @requires the input stream {@code: input} is correctly formatted and the
     *           directory represented by {@code: folder} exists
     * @ensures In the directorty represented by {@code: folder} there are html
     *          files that together make a glossary generated from the input
     *          stream represented by {@code: input}
     * @param folder
     *            The folder to put the html files
     */
    public static void generateGlossary(String input, String folder) {
        SimpleReader inputStream = new SimpleReader1L(input);
        Set<String> terms = generateTerms(inputStream);

        generateIndex(terms, folder);

        inputStream = new SimpleReader1L(input);
        printTermFiles(inputStream, terms, folder);
    }

    /**
     * If this function is called it will print instructions (that require
     * feedback) on how to create a glossary, alternatively the function
     * {@code: generateGlossary} could be called directly.
     */
    public static void userInterface() {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.println("Files are automattically read from the data folder, unless a '~' is before the file path");
        out.println("Files are automattically written into the data/glossary/[specified_file] folder, unless a '~' is before the file path");
        out.println("in which case what follows must be the full file path, if you want to use the default file, just hit enter");
        out.println("Note that the file path must exist and if a glossary is already stored in that folder it will be overwritten\nIf you want to replace the standard file loaction, then click enter without any file specified ");

        out.println();
        out.print("What file do you wish to read from?");

        String file = in.nextLine();

        if (file.equals("")) {
            file = "terms.txt";
        }
        if (!(file.charAt(0) == '~')) {
            file = "data/" + file;
        } else {
            file = file.substring(1);
        }

        out.print("Where do you want your files to be located?");
        String folder = in.nextLine();

        if (folder.equals("")) {
            folder = "glossary";
        }
        if (!(folder.charAt(0) == '~')) {
            folder = "data/" + folder;
        } else {
            folder = folder.substring(1);
        }

        generateGlossary(file, folder);

        in.close();
        out.close();
    }

    /**
     * if this program is run it will automatically call the function {@code:
     * userInterface()}
     * 
     * @param args
     */
    public static void main(String[] args) {
        userInterface();
    }
    /*
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
     * 
    */

}
