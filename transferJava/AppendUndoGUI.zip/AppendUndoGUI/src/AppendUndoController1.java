import components.stack.Stack;

/**
 * Controller class.
 * 
 * @author Bruce W. Weide
 * @author Paolo Bucci
 */
public final class AppendUndoController1 implements AppendUndoController {

    /**
     * Model object.
     */
    private final AppendUndoModel model;

    /**
     * View object.
     */
    private final AppendUndoView view;

    /**
     * Updates view to display model.
     * 
     * @param model
     *            the model
     * @param view
     *            the view
     */
    private static void updateViewToMatchModel(AppendUndoModel model,
            AppendUndoView view) {
        /*
         * Get model info
         */
        String input = model.input();
        Stack<String> output = model.output();
        boolean undoAllowed = true;
        if (output.length() == 0) {
            undoAllowed = false;
        }

        /*
         * Update view to reflect changes in model
         */
        String outputString = "";

        Stack<String> temp = output.newInstance();
        int length = output.length();

        for (int i = 0; i < length; i++) {
            String s = output.pop();
            temp.push(s);
        }

        for (int i = 0; i < length; i++) {
            String s = temp.pop();
            outputString = outputString + s;
            output.push(s);
        }

        // outputString = outputString + input;

        view.updateInputDisplay(input);
        view.updateOutputDisplay(outputString);
        view.updateUndoAllowed(undoAllowed);
    }

    /**
     * Constructor; connects {@code this} to the model and view it coordinates.
     * 
     * @param model
     *            model to connect to
     * @param view
     *            view to connect to
     */
    public AppendUndoController1(AppendUndoModel model, AppendUndoView view) {
        this.model = model;
        this.view = view;
    }

    /**
     * Processes reset event.
     */
    @Override
    public void processResetEvent() {
        /*
         * Update model in response to this event
         */
        this.model.setInput("");
        Stack<String> output = this.model.output();
        output.clear();
        /*
         * Update view to reflect changes in model
         */
        updateViewToMatchModel(this.model, this.view);
    }

    /**
     * Processes copy event.
     * 
     * @param input
     *            value of input text (provided by view)
     */
    @Override
    public void processUndoEvent() {
        Stack<String> output = this.model.output();
        String input = output.pop();
        this.model.setInput(input);
        updateViewToMatchModel(this.model, this.view);
    }

    /**
     * Processes copy event.
     * 
     * @param input
     *            value of input text (provided by view)
     */
    @Override
    public void processAppendEvent(String input) {
        Stack<String> output = this.model.output();
        output.push(input);
        this.model.setInput("");
        updateViewToMatchModel(this.model, this.view);
    }

}
