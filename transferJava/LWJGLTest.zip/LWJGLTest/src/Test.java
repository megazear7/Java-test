import org.lwjgl.LWJGLException;
import org.lwjgl.Sys;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;
import org.lwjgl.opengl.GL11;

public class Test {

    /** position of quad */
    float x = 400, y = 300;
    /** angle of quad rotation */
    float rotation = 0;

    /** time at last frame */
    long lastFrame;

    /** frames per second */
    int fps;
    /** last fps time */
    long lastFPS;

    public void start() {
        try {
            Display.setDisplayMode(new DisplayMode(800, 600));
            Display.create();
        } catch (LWJGLException e) {
            e.printStackTrace();
            System.exit(0);
        }

        this.initGL(); // init OpenGL
        this.getDelta(); // call once before loop to initialise lastFrame
        this.lastFPS = this.getTime(); // call before loop to initialise fps
                                       // timer

        while (!Display.isCloseRequested()) {
            int delta = this.getDelta();

            this.update(delta);
            this.renderGL();

            Display.update();
            Display.sync(60); // cap fps to 60fps
        }

        Display.destroy();
    }

    public void update(int delta) {
        // rotate quad
        this.rotation += 0.15f * delta;

        if (Keyboard.isKeyDown(Keyboard.KEY_LEFT)) {
            this.x -= 0.35f * delta;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_RIGHT)) {
            this.x += 0.35f * delta;
        }

        if (Keyboard.isKeyDown(Keyboard.KEY_UP)) {
            this.y += 0.35f * delta;
        }
        if (Keyboard.isKeyDown(Keyboard.KEY_DOWN)) {
            this.y -= 0.35f * delta;
        }

        // keep quad on the screen
        if (this.x < 0) {
            this.x = 0;
        }
        if (this.x > 800) {
            this.x = 800;
        }
        if (this.y < 0) {
            this.y = 0;
        }
        if (this.y > 600) {
            this.y = 600;
        }

        this.updateFPS(); // update FPS Counter
    }

    /**
     * Calculate how many milliseconds have passed since last frame.
     * 
     * @return milliseconds passed since last frame
     */
    public int getDelta() {
        long time = this.getTime();
        int delta = (int) (time - this.lastFrame);
        this.lastFrame = time;

        return delta;
    }

    /**
     * Get the accurate system time
     * 
     * @return The system time in milliseconds
     */
    public long getTime() {
        return (Sys.getTime() * 1000) / Sys.getTimerResolution();
    }

    /**
     * Calculate the FPS and set it in the title bar
     */
    public void updateFPS() {
        if (this.getTime() - this.lastFPS > 1000) {
            Display.setTitle("FPS: " + this.fps);
            this.fps = 0;
            this.lastFPS += 1000;
        }
        this.fps++;
    }

    public void initGL() {
        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        GL11.glOrtho(0, 800, 0, 600, 1, -1);
        GL11.glMatrixMode(GL11.GL_MODELVIEW);
    }

    public void renderGL() {
        // Clear The Screen And The Depth Buffer
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // R,G,B,A Set The Color To Blue One Time Only
        GL11.glColor3f(0.5f, 0.5f, 1.0f);

        // draw quad
        GL11.glPushMatrix();
        GL11.glTranslatef(this.x, this.y, 0);
        GL11.glRotatef(this.rotation, 0f, 0f, 1f);
        GL11.glTranslatef(-this.x, -this.y, 0);

        GL11.glBegin(GL11.GL_QUADS);
        GL11.glVertex2f(this.x - 50, this.y - 50);
        GL11.glVertex2f(this.x + 50, this.y - 50);
        GL11.glVertex2f(this.x + 50, this.y + 50);
        GL11.glVertex2f(this.x - 50, this.y + 50);
        GL11.glEnd();
        GL11.glPopMatrix();
    }

    public static void main(String[] argv) {
        Test timerExample = new Test();
        timerExample.start();
    }
}