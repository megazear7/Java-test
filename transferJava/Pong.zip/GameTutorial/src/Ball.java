import java.awt.Graphics;

/**
 * A ball for use in a pong game
 * 
 * @author Alex
 * 
 */
public class Ball {
    private int x;
    private int y;
    private final int ballWidth;
    private final int ballHeight;
    private int velX;
    private int velY;
    private GameTutorial Controller;

    Ball(int x, int y, int ballWidth, int ballHeight, int initVelX, int initVelY) {
        this.x = x;
        this.y = y;
        this.ballWidth = ballWidth;
        this.ballHeight = ballHeight;
        this.velX = initVelX;
        this.velY = initVelY;
    }

    Ball() {
        this.x = 0;
        this.y = 0;
        this.ballWidth = 20;
        this.ballHeight = 20;
    }

    void initController(GameTutorial control) {
        this.Controller = control;
    }

    void moveVelocityOveride(int x, int y) {
        this.x += x;
        this.y += y;
    }

    void checkContact(Paddle paddle) {
        if (paddle.player() == 1) {
            if (this.y > paddle.y() && (this.y < paddle.y() + paddle.height())
                    && (this.x < paddle.xCollide())) {
                this.x = paddle.xCollide();
                this.velX = this.velX * -1;
            } else if (paddle.player() == 1) {
                if (this.y + this.ballHeight > paddle.y()
                        && (this.y + this.ballHeight < paddle.y()
                                + paddle.height())
                        && (this.x < paddle.xCollide())) {
                    this.x = paddle.xCollide();
                    this.velX = this.velX * -1;
                }
            }
        } else if (paddle.player() == 2) {
            if (this.y > paddle.y() && (this.y < paddle.y() + paddle.height())
                    && (this.x + this.ballWidth > paddle.x())) {
                this.x = paddle.x() - this.ballWidth;
                this.velX = this.velX * -1;
            } else if (paddle.player() == 2) {
                if (this.y + this.ballHeight > paddle.y()
                        && (this.y + this.ballHeight < paddle.y()
                                + paddle.height())
                        && (this.x + this.ballWidth > paddle.x())) {
                    this.x = paddle.x() - this.ballWidth;
                    this.velX = this.velX * -1;
                }
            }
        }
    }

    void move() {
        this.x += this.velX;
        this.y += this.velY;
    }

    void checkEdge() {
        if ((this.x > this.Controller.windowWidth - this.ballWidth)
                && (this.velX > 0)) {
            this.Controller.endGame("Player 1 Wins!!!");
        }
        if ((this.x < 0) && (this.velX < 0)) {
            this.Controller.endGame("Player 2 Wins!!!");
        }
        if ((this.y > this.Controller.windowHeight - this.ballHeight)
                && (this.velY > 0)) {
            this.velY = this.velY * -1;
        } else if ((this.y < 0) && (this.velY < 0)) {
            this.velY = this.velY * -1;
        }
    }

    void checkStatus() {
        this.checkEdge();
    }

    void drawBall(Graphics g) {
        g.drawOval(this.x, this.y, this.ballWidth, this.ballHeight);
    }

}
