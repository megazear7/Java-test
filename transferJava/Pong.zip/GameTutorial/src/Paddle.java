import java.awt.Graphics;

/*
 * A paddle for a pong game
 */
public class Paddle {
    private int x;
    private int y;
    private final int width;
    private final int height;
    private GameTutorial Controller;
    private final int player;
    private int xCollide;
    private int yBottom;

    Paddle(int x, int y, int width, int height, int player) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.yBottom = this.y + this.height;
        this.player = player;
        if (this.player == 1) {
            this.xCollide = this.width + this.x;
        } else if (this.player == 2) {
            this.xCollide = this.x;
        }
    }

    Paddle() {
        this.x = 0;
        this.y = 0;
        this.width = 20;
        this.height = 20;
        this.player = 1;
        this.yBottom = this.y + this.height;
        if (this.player == 1) {
            this.xCollide = 0;
        } else if (this.player == 2) {
            this.xCollide = 500;
        }
    }

    void initController(GameTutorial control) {
        this.Controller = control;
    }

    void move(int x, int y) {
        this.x += x;
        this.y += y;
    }

    void checkStatus() {
        this.updateXAndY();
        this.checkBounds();
    }

    void updateXAndY() {
        if (this.player == 1) {
            this.xCollide = this.width + this.x;
        } else if (this.player == 2) {
            this.xCollide = this.x;
        }
        this.yBottom = this.y + this.height;
    }

    void checkBounds() {
        if (this.y > this.Controller.windowHeight - this.height) {
            this.y = this.Controller.windowHeight - this.height;
        } else if (this.y < 0) {
            this.y = 0;
        }
    }

    void drawPaddle(Graphics g) {
        g.drawRect(this.x, this.y, this.width, this.height);
    }

    int x() {
        return this.x;
    }

    int y() {
        return this.y;
    }

    int width() {
        return this.width;
    }

    int height() {
        return this.height;
    }

    int player() {
        return this.player;
    }

    int xCollide() {
        return this.xCollide;
    }

    int yBottom() {
        return this.yBottom;
    }

}
