import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 * Main class for the game
 */
public class GameTutorial extends JFrame {

    int fps = 30;
    int windowWidth = 500;
    int windowHeight = 500;
    Ball ball;
    Paddle paddleA;
    Paddle paddleB;
    Paddle test;
    boolean isRunning = true;
    Insets insets;

    BufferedImage backBuffer;

    InputHandler input;

    /**
     * This method starts the game and runs it in a loop
     */
    public void run() {
        this.initialize();
        while (this.isRunning) {

            long time = System.currentTimeMillis();

            this.update();
            this.draw();

            // delay for each frame - time it took for one frame
            time = (1000 / this.fps) - (System.currentTimeMillis() - time);

            if (time > 0) {
                try {
                    Thread.sleep(time);
                } catch (Exception e) {
                }
            }

        }

        // this.setVisible(false);
    }

    /**
     * This method will set up everything need for the game to run
     */
    void initialize() {
        this.setTitle("Game Tutorial");
        this.setSize(this.windowWidth, this.windowHeight);
        this.setResizable(false);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        this.backBuffer = new BufferedImage(this.windowWidth,
                this.windowHeight, BufferedImage.TYPE_INT_RGB);

        this.insets = this.getInsets();
        this.setSize(this.insets.left + this.windowWidth + this.insets.right,
                this.insets.top + this.windowHeight + this.insets.bottom);

        this.input = new InputHandler(this);

        this.ball = new Ball(250, 100, 20, 20, 6, 6);
        this.ball.initController(this);

        this.paddleB = new Paddle(50, 250, 20, 60, 1);
        this.paddleB.initController(this);

        this.paddleA = new Paddle(450, 250, 20, 60, 2);
        this.paddleA.initController(this);

    }

    /**
     * This method will check for input, move things around and check for win
     * conditions, etc
     */
    void update() {

        if (this.input.isKeyDown(KeyEvent.VK_UP)) {
            this.paddleA.move(0, -5);
        }
        if (this.input.isKeyDown(KeyEvent.VK_DOWN)) {
            this.paddleA.move(0, 5);
        }

        if (this.input.isKeyDown(KeyEvent.VK_W)) {
            this.paddleB.move(0, -5);
        }
        if (this.input.isKeyDown(KeyEvent.VK_S)) {
            this.paddleB.move(0, 5);
        }
        this.ball.checkStatus();
        this.paddleA.checkStatus();
        this.paddleB.checkStatus();
        this.ball.move();
        this.ball.checkContact(this.paddleA);
        this.ball.checkContact(this.paddleB);

    }

    /**
     * This method will draw everything
     */
    void draw() {
        Graphics g = this.getGraphics();

        Graphics bbg = this.backBuffer.getGraphics();

        bbg.setColor(Color.WHITE);
        bbg.fillRect(0, 0, this.windowWidth, this.windowHeight);

        bbg.setColor(Color.BLACK);
        this.ball.drawBall(bbg);
        this.paddleA.drawPaddle(bbg);
        this.paddleB.drawPaddle(bbg);

        g.drawImage(this.backBuffer, this.insets.left, this.insets.top, this);

    }

    void endGame(String message) {

        JLabel label = new JLabel(message);
        label.setFont(new Font("Serif", Font.PLAIN, 26));
        this.getContentPane().add(label);
        this.setSize(230, 230); // or whatever size you want
        // Place Frame in middle of Screen
        this.setLocationRelativeTo(null);
        this.setVisible(true);
        this.isRunning = false;

    }

    public static void main(String[] args) {
        GameTutorial game = new GameTutorial();
        game.run();
        // System.exit(0);
    }
}