import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;

public class StringReassemblyTest {

    @Test
    public void overlap_abc_bcd() {
        String s1 = "abc";
        String s2 = "bcd";
        int n = StringReassembly.overlap(s1, s2);
        assertEquals(n, 2);
        assertEquals("abc", s1);
        assertEquals("bcd", s2);
    }

    @Test
    public void overlap_ABC_BCD() {
        String s1 = "ABC";
        String s2 = "BCD";
        int n = StringReassembly.overlap(s1, s2);
        assertEquals(n, 2);
        assertEquals("ABC", s1);
        assertEquals("BCD", s2);
    }

    @Test
    public void overlap_abcdefghi_ijk() {
        String s1 = "abcdefghi";
        String s2 = "ijk";
        int n = StringReassembly.overlap(s1, s2);
        assertEquals(n, 1);
        assertEquals("abcdefghi", s1);
        assertEquals("ijk", s2);
    }

    @Test
    public void combination_abc_bcd() {
        String s1 = "abc";
        String s2 = "bcd";
        String n = StringReassembly.combination(s1, s2, 2);
        assertEquals(n, "abcd");
    }

    @Test
    public void combination_ABC_BCD() {
        String s1 = "ABC";
        String s2 = "BCD";
        String n = StringReassembly.combination(s1, s2, 2);
        assertEquals(n, "ABCD");
    }

    @Test
    public void combination_abcdefghi_ijk() {
        String s1 = "abcdefghi";
        String s2 = "ijk";
        String n = StringReassembly.combination(s1, s2, 1);
        assertEquals(n, "abcdefghijk");
    }

    @Test
    public void addToSetAvoidingSubstrings_ab() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        String s2 = "ab";
        assertTrue(StringReassembly.contains(theSet, s2));
        StringReassembly.addToSetAvoidingSubstrings(theSet, s2);
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void setEqualsTest() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void addToSetAvoidingSubstrings_bill() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        noChange.add("bill");
        String s2 = "bill";
        StringReassembly.addToSetAvoidingSubstrings(theSet, s2);
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void addToSetAvoidingSubstrings_alexman() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("joe");
        noChange.add("alexman");
        String s2 = "alexman";
        StringReassembly.addToSetAvoidingSubstrings(theSet, s2);
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void containsTest_false() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        String s2 = "alexman";
        assertTrue(!StringReassembly.contains(theSet, s2));
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void containsTest_true() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        String s2 = "alex";
        assertTrue(StringReassembly.contains(theSet, s2));
        assertTrue(theSet.equals(noChange));
    }

    @Test
    public void containsTest_true_2() {
        Set<String> theSet = new Set1L<String>();
        Set<String> noChange = theSet.newInstance();
        theSet.add("abc");
        theSet.add("alex");
        theSet.add("joe");
        noChange.add("abc");
        noChange.add("alex");
        noChange.add("joe");
        String s2 = "ab";
        assertTrue(StringReassembly.contains(theSet, s2));
        assertTrue(theSet.equals(noChange));
    }
}
