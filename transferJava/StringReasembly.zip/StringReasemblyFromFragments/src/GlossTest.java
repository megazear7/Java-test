import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

public class GlossTest {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private GlossTest() {
    }

    public static void main(String[] args) {
        SimpleReader input = new SimpleReader1L("data/terms.txt");
        SimpleWriter out = new SimpleWriter1L();

        Set<String> terms = new Set1L<String>();
        String term;
        while (!input.atEOS()) {
            term = input.nextLine();

            if (!terms.contains(term)) {
                terms.add(term);
            }

            input.nextLine();
            input.nextLine();
        }

        input.close();
        out.close();
    }

}
